
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path/path.dart' as p;

void main() {
  runApp(ShadowChatApp());
}

class ShadowChatApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Shadow Chat',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: Colors.black,
        textTheme: TextTheme(
          bodyMedium: TextStyle(color: Color(0xFFFFD700)),
        ),
      ),
      home: HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  final List<Map<String, dynamic>> features = [
    {
      "title": "Offline Communication",
      "desc": "Works without internet using Bluetooth mesh networking",
      "icon": Icons.bluetooth
    },
    {
      "title": "End-to-End Encryption",
      "desc": "All messages encrypted with Curve25519 + AES-GCM",
      "icon": Icons.lock
    },
    {
      "title": "Extended Range",
      "desc": "Messages relay through peers, reaching 300m+",
      "icon": Icons.wifi_tethering
    },
    {
      "title": "Favorites System",
      "desc": "Store-and-forward messages for favorites privately",
      "icon": Icons.star
    },
    {
      "title": "@ Mentions",
      "desc": "Mention specific users",
      "icon": Icons.alternate_email
    },
    {
      "title": "# Topics",
      "desc": "Join conversations with hashtags",
      "icon": Icons.tag
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Shadow Chat', style: TextStyle(color: Color(0xFFFFD700))),
        backgroundColor: Colors.black,
        centerTitle: true,
        elevation: 0,
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              padding: EdgeInsets.all(16),
              itemCount: features.length,
              itemBuilder: (context, index) {
                final feature = features[index];
                return ListTile(
                  leading: Icon(feature['icon'], color: Color(0xFFFFD700)),
                  title: Text(feature['title'], style: TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text(feature['desc']),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xFFFFD700),
                foregroundColor: Colors.black,
              ),
              icon: Icon(Icons.chat),
              label: Text('ابدأ الدردشة'),
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => ChatPage()));
              },
            ),
          )
        ],
      ),
    );
  }
}

class ChatPage extends StatefulWidget {
  @override
  _ChatPageState createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  List<Map<String, dynamic>> messages = [];
  final TextEditingController controller = TextEditingController();

  void sendMessage(String text) {
    if (text.trim().isEmpty) return;
    setState(() {
      messages.add({"type": "text", "content": text.trim()});
      controller.clear();
    });
  }

  void sendFile() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles();
    if (result != null && result.files.single.path != null) {
      String fileName = p.basename(result.files.single.path!);
      setState(() {
        messages.add({"type": "file", "content": fileName});
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("الدردشة", style: TextStyle(color: Color(0xFFFFD700))),
        backgroundColor: Colors.black,
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              padding: EdgeInsets.all(12),
              itemCount: messages.length,
              itemBuilder: (context, index) {
                final msg = messages[index];
                return Align(
                  alignment: Alignment.centerRight,
                  child: Container(
                    margin: EdgeInsets.symmetric(vertical: 6),
                    padding: EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: msg['type'] == 'file' ? Colors.blueGrey : Color(0xFF1E1E1E),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      msg['type'] == 'file' ? '📁 ملف: ${msg['content']}' : msg['content'],
                      style: TextStyle(color: Color(0xFFFFD700)),
                    ),
                  ),
                );
              },
            ),
          ),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            color: Colors.black,
            child: Row(
              children: [
                IconButton(
                  icon: Icon(Icons.attach_file, color: Color(0xFFFFD700)),
                  onPressed: sendFile,
                ),
                Expanded(
                  child: TextField(
                    controller: controller,
                    style: TextStyle(color: Color(0xFFFFD700)),
                    decoration: InputDecoration(
                      hintText: "اكتب رسالة...",
                      hintStyle: TextStyle(color: Colors.grey),
                      border: InputBorder.none,
                    ),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.send, color: Color(0xFFFFD700)),
                  onPressed: () => sendMessage(controller.text),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
